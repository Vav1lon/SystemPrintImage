﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Printing;
using System.Drawing;

namespace SPimg
{
    public class FormatDetector
    {
        public PaperSize DetectFormat(string filePath)
        {
            var image = new Bitmap(filePath, true);
            
            //Высота 
            double Hmm = (image.Size.Height / image.VerticalResolution) * 25.4;
            //Ширина
            double Wmm = (image.Size.Width / image.HorizontalResolution) * 25.4;

            var pageSize = DetectPageSize(Wmm, Hmm);
            if (pageSize == null)
                throw new UknownDrawingFormatException(string.Format("Не удается определить формат чертежа {0}.", filePath));

            return pageSize;
        }

        private PaperSize DetectPageSize(double Wmm, double Hmm)
        {

            Wmm = Math.Round(Wmm, 0);
            Hmm = Math.Round(Hmm, 0);

            PaperSize a4albom = new PaperSize("A4 (Альбом)", 297, 210);
            PaperSize a4kniga = new PaperSize("A4 (Книга)", 210, 297);

            if (Wmm < a4albom.Width + 10 && Hmm < a4albom.Height + 10) { return a4albom; }
            if (Wmm < a4kniga.Width + 10 && Hmm < a4kniga.Height + 10) { return a4kniga; }

            PaperSize a3albom = new PaperSize("A3 (Альбом)", 420, 297);
            PaperSize a3kniga = new PaperSize("A3 (Книга)", 297, 420);

            if (Wmm < a3albom.Width + 44 && Hmm < a3albom.Height + 44) { return a3albom; }
            if (Wmm < a3kniga.Width + 44 && Hmm < a3kniga.Height + 44) { return a3kniga; }

            PaperSize a2albom = new PaperSize("A2 (Альбом)", 594, 420);
            PaperSize a2kniga = new PaperSize("A2 (Книга)", 420, 549);

            if (Wmm < a2albom.Width + 88 && Hmm < a2albom.Height + 88) { return a2albom; }
            if (Wmm < a2kniga.Width + 88 && Hmm < a2kniga.Height + 88) { return a2kniga; }

            PaperSize a1albom = new PaperSize("A1 (Альбом)", 549, 841);
            PaperSize a1kniga = new PaperSize("A1 (Книга)", 841, 549);

            if (Wmm < a1albom.Width + 176 && Hmm < a1albom.Height + 176) { return a1albom; }
            if (Wmm < a1kniga.Width + 176 && Hmm < a1kniga.Height + 176) { return a1kniga; }

            return null;
        }
    }

    [global::System.Serializable]
    public class UknownDrawingFormatException : Exception
    {
        public UknownDrawingFormatException() { }
        public UknownDrawingFormatException(string message) : base(message) { }
        public UknownDrawingFormatException(string message, Exception inner) : base(message, inner) { }
        protected UknownDrawingFormatException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
